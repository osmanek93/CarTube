package me.aap.fermata.addon.web;

import androidx.annotation.Keep;

import me.aap.utils.ui.view.ToolBarView;

/**
 * Canlı TV sekmesi: tarayıcıdan farkı, adres çubuğu olmaması ve
 * her zaman demtv sitesini açmasıdır.
 */
@Keep
@SuppressWarnings("unused")
public class LiveTvFragment extends WebBrowserFragment {
	public static final String LIVE_TV_URL = "https://demtv.demiralayboncuk-092.workers.dev/";

	@Override
	public ToolBarView.Mediator getToolBarMediator() {
		return ToolBarView.Mediator.Invisible.instance;
	}

	@Override
	protected String getSearchUrl() {
		return LIVE_TV_URL + "?q=";
	}
}
