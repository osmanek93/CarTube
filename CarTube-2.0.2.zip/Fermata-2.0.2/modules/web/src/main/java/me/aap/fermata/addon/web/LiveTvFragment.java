package me.aap.fermata.addon.web;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import me.aap.utils.ui.view.ToolBarView;

/**
 * Canlı TV sekmesi: tarayıcıdan farkı, adres çubuğu olmaması ve
 * her zaman demtv sitesini açmasıdır.
 */
@Keep
@SuppressWarnings("unused")
public class LiveTvFragment extends WebBrowserFragment {
	public static final String LIVE_TV_URL = "https://demtv.demiralayboncuk-092.workers.dev/";
	private final MapPanel map = new MapPanel("livetv");

	@Override
	public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		map.init(this, view);
	}

	@Override
	public void onDestroyView() {
		map.destroy();
		super.onDestroyView();
	}

	@Override
	public ToolBarView.Mediator getToolBarMediator() {
		return ToolBarView.Mediator.Invisible.instance;
	}

	@Override
	protected String getSearchUrl() {
		return LIVE_TV_URL + "?q=";
	}
}
