package me.aap.fermata.addon.web;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

import java.util.HashMap;
import java.util.Map;

/**
 * Sağdaki Yandex Haritalar paneli ve ortadaki aç/kapa oku.
 * Her sekmenin durumu uygulama açık kaldığı sürece hatırlanır; uygulama
 * ilk açıldığında harita her sekmede açık gelir.
 */
public final class MapPanel {
	private static final String MAP_URL = "https://yandex.com.tr/harita/";
	private static final String DESKTOP_UA =
			"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
					+ "Chrome/124.0.0.0 Safari/537.36";
	private static final Map<String, Boolean> OPEN = new HashMap<>();

	private final String key;
	private WebView web;

	public MapPanel(String key) {
		this.key = key;
	}

	private boolean isOpen() {
		Boolean b = OPEN.get(key);
		return b == null || b;
	}

	@SuppressLint("SetJavaScriptEnabled")
	public void init(Fragment f, View root) {
		web = root.findViewById(R.id.mapWebView);
		View panel = root.findViewById(R.id.mapPanel);
		ImageView toggle = root.findViewById(R.id.mapToggle);
		if (web == null || panel == null || toggle == null) return;

		if (root.getContext().checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
				!= PackageManager.PERMISSION_GRANTED) {
			f.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
					Manifest.permission.ACCESS_COARSE_LOCATION}, 7001);
		}

		WebSettings ws = web.getSettings();
		ws.setJavaScriptEnabled(true);
		ws.setDomStorageEnabled(true);
		ws.setGeolocationEnabled(true);
		ws.setUserAgentString(DESKTOP_UA);
		ws.setUseWideViewPort(true);
		ws.setLoadWithOverviewMode(true);
		ws.setSupportZoom(true);
		ws.setBuiltInZoomControls(true);
		ws.setDisplayZoomControls(false);

		web.setWebViewClient(new WebViewClient());
		web.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onGeolocationPermissionsShowPrompt(String origin,
																											GeolocationPermissions.Callback cb) {
				cb.invoke(origin, true, false);
			}
		});
		web.loadUrl(MAP_URL);

		apply(panel, toggle);
		toggle.setOnClickListener(v -> {
			OPEN.put(key, !isOpen());
			apply(panel, toggle);
		});
	}

	private void apply(View panel, ImageView toggle) {
		boolean open = isOpen();
		panel.setVisibility(open ? View.VISIBLE : View.GONE);
		// Harita açıkken ok sağa bakar (haritayı kapat), kapalıyken sola bakar (haritayı aç)
		toggle.setRotation(open ? 0f : 180f);
	}

	public void destroy() {
		if (web != null) {
			web.stopLoading();
			web.destroy();
			web = null;
		}
	}
}
