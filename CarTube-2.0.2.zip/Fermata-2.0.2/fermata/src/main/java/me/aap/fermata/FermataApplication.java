package me.aap.fermata;

import static me.aap.fermata.ui.activity.MainActivityPrefs.LOCALE;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.Locale;

import me.aap.fermata.addon.AddonManager;
import me.aap.fermata.media.engine.BitmapCache;
import me.aap.fermata.ui.activity.MainActivityPrefs;
import me.aap.fermata.vfs.FermataVfsManager;
import me.aap.utils.app.App;
import me.aap.utils.app.NetSplitCompatApp;
import me.aap.utils.log.Log;
import me.aap.utils.pref.PreferenceStore;
import me.aap.utils.pref.SharedPreferenceStore;
import me.aap.utils.ui.activity.ActivityDelegate;

/**
 * @author Andrey Pavlenko
 */
public class FermataApplication extends NetSplitCompatApp {
	private FermataVfsManager vfsManager;
	private BitmapCache bitmapCache;
	private volatile SharedPreferenceStore preferenceStore;
	private volatile AddonManager addonManager;
	private int mirroringMode;
	private ServiceConnection eventService;

	public static FermataApplication get() {
		return App.get();
	}

	@Override
	public void onCreate() {
		super.onCreate();
		var appCtx = this;
		Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
			try {
				var sw = new java.io.StringWriter();
				e.printStackTrace(new java.io.PrintWriter(sw));
				var tr = sw.toString();
				if (tr.length() > 6000) tr = tr.substring(0, 6000);
				var i = new Intent(appCtx, CrashActivity.class);
				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
				i.putExtra("trace", tr);
				appCtx.startActivity(i);
				Thread.sleep(1500);
			} catch (Throwable ignored) {
			}
			android.os.Process.killProcess(android.os.Process.myPid());
			System.exit(10);
		});
		startHangWatchdog();
		vfsManager = new FermataVfsManager();
		bitmapCache = new BitmapCache();
	}

	@Override
	protected void attachBaseContext(Context ctx) {
		var ps = SharedPreferenceStore.create(ctx.getSharedPreferences("fermata", MODE_PRIVATE));
		if (ps.hasPref(LOCALE)) {
			var loc = MainActivityPrefs.Lang.get(ps.getIntPref(LOCALE)).locale;
			var cfg = ctx.getResources().getConfiguration();
			cfg.setLocale(loc);
			Locale.setDefault(loc);
			ctx = ctx.createConfigurationContext(cfg);
		} else {
			preferenceStore = ps;
		}
		super.attachBaseContext(ctx);
	}

	public boolean isConnectedToAuto() {
		return BuildConfig.AUTO && ActivityDelegate.getContextToDelegate() != null;
	}

	public FermataVfsManager getVfsManager() {
		return vfsManager;
	}

	public BitmapCache getBitmapCache() {
		return bitmapCache;
	}

	public PreferenceStore getPreferenceStore() {
		SharedPreferenceStore ps = preferenceStore;

		if (ps == null) {
			synchronized (this) {
				if ((ps = preferenceStore) == null) {
					preferenceStore =
							ps = SharedPreferenceStore.create(getSharedPreferences("fermata", MODE_PRIVATE));
				}
			}
		}

		return ps;
	}

	public SharedPreferences getDefaultSharedPreferences() {
		return ((SharedPreferenceStore) getPreferenceStore()).getSharedPreferences();
	}

	public AddonManager getAddonManager() {
		AddonManager mgr = addonManager;

		if (mgr == null) {
			synchronized (this) {
				if ((mgr = addonManager) == null) {
					addonManager = mgr = new AddonManager(getPreferenceStore());
				}
			}
		}

		return mgr;
	}

	@Override
	protected int getMaxNumberOfThreads() {
		return 5;
	}

	@NonNull
	@Override
	public File getLogFile() {
		File dir = getExternalFilesDir(null);
		if (dir == null) dir = getFilesDir();
		return new File(dir, "Fermata.log");
	}

	@Nullable
	@Override
	public String getCrashReportEmail() {
		return "andrey.a.pavlenko@gmail.com";
	}

	public boolean isMirroringMode() {
		return BuildConfig.AUTO && getMirroringMode() != 0;
	}

	public boolean isMirroringLandscape() {
		return BuildConfig.AUTO && getMirroringMode() == 1;
	}

	public int getMirroringMode() {
		return mirroringMode;
	}

	public void setMirroringMode(int mirroringMode) {
		if (!BuildConfig.AUTO) return;
		this.mirroringMode = mirroringMode;

		if (mirroringMode == 0) {
			if (eventService != null) {
				unbindService(eventService);
				eventService = null;
			}
		} else if (eventService == null) {
			eventService = new ServiceConnection() {
				@Override
				public void onServiceConnected(ComponentName name, IBinder service) {
					Log.d("Connected to XposedEventDispatcherService");
				}

				@Override
				public void onServiceDisconnected(ComponentName name) {
					Log.d("Disconnected from XposedEventDispatcherService");
				}
			};
			try {
				Log.i("Starting XposedEventDispatcherService");
				var i = new Intent();
				i.setComponent(
						new ComponentName(this, "me.aap.fermata.auto" + ".XposedEventDispatcherService"));
				bindService(i, eventService, Context.BIND_AUTO_CREATE);
			} catch (Exception err) {
				eventService = null;
				Log.e(err, "Failed to bind EventDispatcherService");
			}
		}
	}

	/** Ana iş parçacığı 8 sn'den uzun donarsa, takıldığı yeri CrashActivity'de gösterir. */
	private void startHangWatchdog() {
		var appCtx = this;
		var main = new android.os.Handler(android.os.Looper.getMainLooper());
		var t = new Thread(() -> {
			var shown = false;
			while (!shown) {
				try {
					var ack = new java.util.concurrent.atomic.AtomicBoolean(false);
					main.post(() -> ack.set(true));
					Thread.sleep(8000);
					if (!ack.get()) {
						var sb = new StringBuilder("TAKILMA: ana ekran 8 sn'den uzun yanıt vermedi.\n\n");
						for (var el : android.os.Looper.getMainLooper().getThread().getStackTrace()) {
							sb.append("\tat ").append(el).append('\n');
						}
						var i = new Intent(appCtx, CrashActivity.class);
						i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						i.putExtra("trace", sb.toString());
						appCtx.startActivity(i);
						shown = true;
					}
				} catch (Throwable ignored) {
					return;
				}
			}
		}, "hang-watchdog");
		t.setDaemon(true);
		t.start();
	}
}
