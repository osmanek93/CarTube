package me.aap.fermata.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import me.aap.fermata.R;
import me.aap.fermata.ui.activity.MainActivityDelegate;
import me.aap.utils.ui.view.ToolBarView;

/**
 * Ana ekran: solda YouTube, sağda Canlı TV kartı.
 */
public class HomeFragment extends MainActivityFragment {

	@Override
	public int getFragmentId() {
		return R.id.home_fragment;
	}

	@Nullable
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
													 @Nullable Bundle savedInstanceState) {
		return inflater.inflate(R.layout.home_fragment, container, false);
	}

	@Override
	public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		view.findViewById(R.id.home_youtube).setOnClickListener(v ->
				MainActivityDelegate.get(v.getContext()).showFragment(R.id.youtube_fragment));
		view.findViewById(R.id.home_livetv).setOnClickListener(v ->
				MainActivityDelegate.get(v.getContext()).showFragment(R.id.web_browser_fragment));
	}

	@Override
	public ToolBarView.Mediator getToolBarMediator() {
		return ToolBarView.Mediator.Invisible.instance;
	}
}
