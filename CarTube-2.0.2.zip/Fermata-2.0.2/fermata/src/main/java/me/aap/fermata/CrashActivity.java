package me.aap.fermata;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;

/** Uygulama çökünce hatayı ekranda gösterir (ayrı süreçte çalışır). */
public class CrashActivity extends Activity {
	@Override
	protected void onCreate(Bundle b) {
		super.onCreate(b);
		String trace = getIntent().getStringExtra("trace");
		TextView tv = new TextView(this);
		tv.setText("CarTube çöktü. Bu ekranın görüntüsünü gönder:\n\n" + trace);
		tv.setTextColor(Color.WHITE);
		tv.setTextSize(11);
		tv.setPadding(24, 48, 24, 24);
		tv.setTextIsSelectable(true);
		ScrollView sv = new ScrollView(this);
		sv.setBackgroundColor(Color.BLACK);
		sv.addView(tv, new ViewGroup.LayoutParams(-1, -2));
		setContentView(sv);
	}
}
